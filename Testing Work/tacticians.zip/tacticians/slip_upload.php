<?php

$msg = "";

 //if upload button is pressed
if(isset($_POST['upload'])){
    
//the path to store the upload image
$target = "images/".basename($_FILES['image']['name']);
    
    //connect to the database
    $db = mysqli_connect("localhost","root","","anu");
    
    //get all the subnetted data from the form
    $image = $_FILES['image']['name'];
    $text = $_POST['text'];
    $userid=$_POST['userid'];
    $pauper_email=$_POST['pauper_email'];
    
// $resultsets = mysqli_query($db,"select distinct user.uid, user.pid, user not exists (select null pauper user.uid = pauper.uid )"); 

//echo $resultsets;

   $sql = "INSERT INTO slip(image,text,userid,pauper_email) VALUES ('$image','$text','$userid','$pauper_email')";
    mysqli_query($db,$sql);
    
    if(move_uploaded_file($_FILES['image']['tmp_name'],$target)){
        $msg = "Image Uploaded Sucessfully";
    }
    else
    {
    $msg = "there is a problem";
    }
}
 header("Location:finalhtml.html"); 
?>