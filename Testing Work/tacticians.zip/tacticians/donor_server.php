<?php


 require 'connection.php';
$conn    = Connect();

$name    = $conn->real_escape_string($_POST['name']);
$password   = $conn->real_escape_string($_POST['password']);
$email    = $conn->real_escape_string($_POST['email']);
$nic   = $conn->real_escape_string($_POST['nic']);
$contactno   = $conn->real_escape_string($_POST['phoneno']);
$address   = $conn->real_escape_string($_POST['address']);

$query1   = mysqli_query($conn,"INSERT into user(name,password,email,nic,phoneno,address) VALUES('" . $name . "','" . md5($password) . "','". $email . "','" .$nic . "','" .$phoneno . "','" .$address . "')");



//$userid = mysqli_insert_id($conn);

//$query2   = mysqli_query($conn,"INSERT into donor3(contactno,address,uid) VALUES('" . $contactno . "','" . $address . "','" .$userid . "')");
 


if (!($query1)) {
  die("Couldn't enter data: ".$conn->error);
 
}
//header("Location: http://www.waitroseflorist.com/flowers/flowers/");

header("Location:donor_check.php");

//echo "Thank You For Contacting Us <br>";
 
$conn->close();
 












?>

























//$query   = "INSERT into user(name,NIC_no,Contact_no,address,post_no) VALUES('" . $name . "','" . $NIC_no . "','". $Contact_no . "','" . $address . "','" . $post_no . "')";


//$password=md5($password_1);
$query1   = "INSERT into user(name,password,email,nic) VALUES('" . $name . "','" . $password . "','". $email . "','" . $nic . "')";

$query2   = "INSERT into donor3(contactno,address) VALUES('" . $contactno . "','" . $address . "')";
  
//$success1 = $conn->query($query1);

$success1 = $conn->query($query1);
$success2 = $conn->query($query2);

if (!(($success1)&&($success2))) {
    die("Couldn't enter data: ".$conn->error);
 
}
//header("Location: http://www.waitroseflorist.com/flowers/flowers/");

header("Location:donar pay last.php");

//echo "Thank You For Contacting Us <br>";
 
$conn->close();
?>