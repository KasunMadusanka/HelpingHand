<?php
 require 'connection.php';
$conn    = Connect();

$name    = $conn->real_escape_string($_POST['name']);
$password   = $conn->real_escape_string($_POST['password']);
$email    = $conn->real_escape_string($_POST['email']);
$nic   = $conn->real_escape_string($_POST['nic']);
$phoneno   = $conn->real_escape_string($_POST['phoneno']);
$address   = $conn->real_escape_string($_POST['address']);
$area   = $conn->real_escape_string($_POST['area']);


//ensure that form fields are filled properly

if(empty($name)){
array_push($errors,"Name is required");
}
if(empty($password)){
array_push($errors,"Password is required");
}
if(empty($email)){
array_push($errors,"Emai is required");
}
if(empty($nic)){
array_push($errors,"NIC is required");
}
if(empty($phoneno)){
array_push($errors,"Telephone number is required");
}
if(empty($address)){
array_push($errors,"Address is required");
}




//if there are no errors, save user to database
if(count($errors)==0){
$query1   = mysqli_query($conn,"INSERT into user(name,password,email,nic,phoneno,address) VALUES('" . $name . "','" . md5($password) . "','". $email . "','" .$nic . "','" .$phoneno . "','" .$address . "')");



$userid = mysqli_insert_id($conn);

$query2   = mysqli_query($conn,"INSERT into pauper(area,uid) VALUES('" .$area . "','" .$userid . "')");
 
}








if (!(($query1)&&($query2))) {
  die("Couldn't enter data: ".$conn->error);
 
}
//header("Location: http://www.waitroseflorist.com/flowers/flowers/");

header("Location:pauper_check.php");

//echo "Thank You For Contacting Us <br>";
 
$conn->close();
 
?>