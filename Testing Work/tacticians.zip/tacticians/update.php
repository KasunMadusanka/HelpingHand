<?php

$db = NEW MySQLi("localhost","root","","anu");
//echo "car";

$helpid = $_GET[helpid];

//echo $helpid;

//echo "car";

//UPDATE help SET is_verified=1 WHERE helpid='$helpid';
    
    
 $resultsets = mysqli_query($db,"UPDATE help SET is_verified=1 WHERE helpid='$helpid'");
    
echo $resultsets;



    mysqli_query($db,$resultsets);


 header('location:finalhtml.html');



?>