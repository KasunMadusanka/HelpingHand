<?php

$msg = "";

 //if upload button is pressed name of button
if(isset($_POST['submit'])){
   
     //connect to the database
    $db = mysqli_connect("localhost","root","","anu");
    
    
    
 $resultsets = mysqli_query($db,"select pauper.pid FROM (user INNER JOIN pauper on user.uid=pauper.uid)");
    
if($resultsets->num_rows > 0){
   while($rows = $resultsets->fetch_assoc()){  
        $pid = $rows['pid'];
    
   }
 }
    
  

    
   
     //the path to store the upload image
   $target = "images/".basename($_FILES['image']['name']);
    
   
    //get all the subnetted data from the form
    
    
    $ename = $_POST['name'];
    $date = $_POST['date'];
    $timefrom = $_POST['time_from'];
    $timeto = $_POST['time_to'];
    $venue = $_POST['venue'];
    $area = $_POST['area'];
    $text = $_POST['text'];
    $doc = $_FILES['image']['name'];
    
    
    
    
    
    
    //get verifier id
    $getVid = mysqli_query($db,"select * FROM verifier WHERE area='$area'");
    
    
    if($getVid->num_rows > 0){
    
     while($rows = $getVid->fetch_assoc()){
        $vid = $rows['verifierid'];
     }
    
    }
    
    
    
    
    
    //insert data into help table
    $sql = "INSERT INTO help(is_verified,verifierid,pid,document,area) VALUES ('0','$vid','$pid','$doc','$area')";
    mysqli_query($db,$sql);
    
    
    
     $getHelpId = mysqli_query($db,"select * FROM help WHERE pid='$pid'");
    
    
    if($getHelpId->num_rows > 0){
     while($rows = $getHelpId->fetch_assoc()){
        $hid = $rows['helpid'];
     }
    }

    

    $sql1 = "INSERT INTO event_request(time_to,time_from,event_date,event_name,venue,area,helpid,discription) VALUES ('$timeto','$timefrom','$date','$ename','$venue','$area','$hid','$text')";
    mysqli_query($db,$sql1);
    
  header("location: pending.php"); 
    
    
    
  /*  
    if($delete->num_rows > 0){
     while($rows = $delete->fetch_assoc()){
        $hid = $rows['helpid'];
        
        "DELETE FROM `money_request` WHERE hid='$hid'";
     }
    }*/
    
        
}
?>