<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Create Event</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-theme.css">
    <link rel="stylesheet" href="custom2.css">
    <link rel="stylesheet" href="icon.css">
    <link rel="stylesheet" href="awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

    <div class="jamo">

        <div class="container">
            <h3>Helping Hand</h3>
            <h1>JOIN with us</h1>



            <div class="container" style="margin-top:50px">
                <div class="row">
                    <div class="col-md-offset-1 col-md-11 col-md-offset-1">
                        <div class="panel panel-default">
                            <div class="panel-body">

                               <!-- <form action="" class="col-md-12" style="margin-top:0px padding-top: 0px;">-->

                                   <!-- <div class="col-md-8">
                                  </div> -->

                                    <div class="col-md-4">
                                        <h2 style="color:yellow;margin-top:40px;text-align: center;font-size:50px;">WELCOME</h2>
                                        
                                    </div>


                               <!-- </form>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container" style="margin-top:0px; padding-top: 0px; padding-left:0px;">
    <div class="row">
        
        
        
        
        
            <form action="EventPauperConnect.php" method="post" style="margin-top:0px; padding-top: 0px; padding-left:0px;" enctype="multipart/form-data">

                <div class="col-md-8">
                    
                    
                    

                    <h2>Create Event</h2>
                    
                    
                    

                    <div class="form-group-2">
                        <label for="inputEmail" class="col-md-3 lig">Event Name </label>
                        <div>
                            <input type="text" name="name" class="form-control-2" id="name" placeholder="  Event name" required>
                        </div>
                    </div>



                    <div class="form-group-2">
                        <label class="col-md-3 lig">Date </label>
                        <div>
                            <input type="date" name="date" class="form-control-2" placeholder="  date " required>
                        </div>
                    </div>



                    <div class="form-group-2">
                    <label class="col-md-3 lig">Time From </label>
                        <div>
                            <input type=time name="time_from" class="form-control-2" placeholder="Time_from" required> 
                            
                        </div>
                    </div>

                    
                    
                    <div class="form-group-2">
                    <label class="col-md-3 lig">Time To </label>
                        <div>
                            <input type="time" name="time_to" class="form-control-2" placeholder="Time_from  " required> 
                            
                        </div>
                    </div>
                    

                    
                    <div class="form-group-2">
                        <label class="col-md-3 lig">Venue </label>
                        
                        <div>
                            <input type="text" name="venue" class="form-control-2" placeholder="  venue" required> 
                            
                        </div>
                    </div>

                    
                     <div class="form-group-2">
                        <label class="col-md-3 lig">Area </label>
                        <div>
                            <select class="form-control-2" type="text" name="area" required>
                            <option>Galle</option>
                                <option>Mathara</option>
                                <option>Colombo</option>
                                <option>Kandy</option>
                             </select>
                        <!--  <input type="text" name="area" class="form-control-2" placeholder="  area"> -->
                            
                        </div>
                    </div>
                    

                    
                    
                    <div class="form-group-2">
                        <label class="col-md-3 lig">Discription </label>
                        <div>
                            <textarea name="text" cols="40" class="form-control-2" rows="4" placeholder="say something about this event..." required></textarea>
                        </div>
                    </div>



                    
                     <div class="form-group-2">
                        <label class="col-md-3 lig">Verification Document </label>
                        <div>
                           <input type="file" name="image" required>
                        </div>
                    </div>
                    <div class="form-group"></div>
                    
                    
                    
                    

                    <button class="btn-noveri" name="submit">REGISTER</button>
                    

                    
                </div>
                
                
                
            </form>
        </div>

    </div>






    <!--Start of the footer-->

    <footer class="site-footer">
        <div class="container">
            <div class="row">


                <div class="col-md-2">
                    <p class="footer">Helping Hand </p>
                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="glyphicon glyphicon-envelope fa-2x"></i></a>
                    <a href="Helpinghand@gmail.com">Helpinghand@gmail.com</a><br><br>
                    <a href="sitemap.html">site map</a>

                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                    <a href="https://www.facebook.com/x">https://www.facebook.com</a>
                </div>





                <div class="github" style="padding-top:20px">
                    <a href="#"><i class="fa fa-github fa-2x"></i></a> - <a href="https://github.com/KasunMadusanka/testing">https://github.com/KasunMadusanka/testing</a>
                </div>


            </div>

            <div class="bottom-footer">
                <div class="col-md-6"> </div>

            </div>


        </div>

    </footer>

    <!--End Of the Footer-->

</body>





</html>