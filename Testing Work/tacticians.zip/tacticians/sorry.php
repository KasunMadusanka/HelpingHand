<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Transparent Login Form</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-theme.css">
    <link rel="stylesheet" href="custom.css">
    <link rel="stylesheet" href="icon.css">
    <link rel="stylesheet" href="awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    
	<!-- Top menu -->
			
    <div class="container">
        
        <h3>Helping Hand</h3>
        <h1>JOIN with us</h1>
<div class="container" style="margin-top:108px">
            <div class="row">

                <div class="col-md-offset-1 col-md-11 col-md-offset-1">

                    <div class="panel panel-default">
                        <div class="panel-body">

                            <form action="login2_server.php" method="post" style="margin-top:0px padding-top: 0px;">
                                
                                <h3> Sorry!!! Your email and password are invalid   <br>
                                Try again</h3>
                                

                                <div class="form-group">
                                    <label for="inputEmail" class="col-md-2 light">Email </label>
                                    <div class="col-md-4">
                                        <input type="text" name="email" class="form-control" id="email" placeholder="  Enter Email">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputEmail" class="col-md-2 light">Password </label>
                                    <div class="col-md-4">
                                        <input type="password" name="password" id="password" class="form-control" placeholder="*************">
                                    </div>
                                </div>

                                <div class="form-group">

                                    <div class="col-md-8">
                                <a href="finalhtml.php">       <input type="submit" class="login" name="login" value=" LOGIN"></a>  or
                                        <a href="pauper_reg.php" class="register"> <u> REGISTER as PAUPER</u></a> here
                                    </div>

                                    <div class="col-md-8">
                                        <a href="donor_reg.php" class="register"> <u> REGISTER as DONER</u></a> here
                                    </div>


                                </div>



                            </form>

                        </div>
                    </div>

                </div>


            </div>


        </div>

    </div>

    <!--Start of the footer-->

    <footer class="site-footer">
        <div class="container">
            <div class="row">


                <div class="col-md-2">
                    <p>Helping Hand </p>
                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="glyphicon glyphicon-envelope fa-2x"></i></a>
                    <a href="Helpinghand@gmail.com">Helpinghand@gmail.com</a><br><br>
                    <a href="sitemap.html">site map</a>

                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                    <a href="https://www.facebook.com/x">https://www.facebook.com</a>
                </div>





                <div class="github" style="padding-top:20px">
                    <a href="#"><i class="fa fa-github fa-2x"></i></a> - <a href="https://github.com/KasunMadusanka/testing">https://github.com/KasunMadusanka/testing</a>
                </div>


            </div>

            <div class="bottom-footer">
                <div class="col-md-6"> </div>

            </div>

        </div>

    </footer>

    <!--End Of the Footer-->

</body>





</html>