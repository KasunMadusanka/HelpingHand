<?php
 require 'connection.php';
$conn    = Connect();

$name    = $conn->real_escape_string($_POST['name']);
$password   = $conn->real_escape_string($_POST['password']);
$email    = $conn->real_escape_string($_POST['email']);
$nic   = $conn->real_escape_string($_POST['nic']);
$phoneno   = $conn->real_escape_string($_POST['phoneno']);
$address   = $conn->real_escape_string($_POST['address']);






//if there are no errors, save user to database
if(count($errors)==0){
$query1   = mysqli_query($conn,"INSERT into user(name,password,email,nic,phoneno,address) VALUES('" . $name . "','" . md5($password) . "','". $email . "','" .$nic . "','" .$phoneno . "','" .$address . "')");



$userid = mysqli_insert_id($conn);

$query2   = mysqli_query($conn,"INSERT into donor(uid) VALUES('" .$userid . "')");
 
}








if (!(($query1)&&($query2))) {
  die("Couldn't enter data: ".$conn->error);
 
}


header("Location:donor_check.php");

//echo "Thank You For Contacting Us <br>";
 
$conn->close();
 
?>