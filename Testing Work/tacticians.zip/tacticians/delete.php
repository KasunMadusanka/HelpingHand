<?php
		 
	
		
		$con = mysqli_connect('localhost','root','','anu');

//echo $_GET[mhid];

//$sd = $_GET[pid];

        $query = "DELETE FROM money_request where mhid='$_GET[mhid]'"; // Or whatever your primary key is for the row, in my case "id". LIMIT 1 kind of gives added assurance that it won't delete tons of stuff if you make a mistake.

//execute the query
      if(mysqli_query($con,$query))
                 header('location:index1.php');   //replace with the location of the page that you need it to redirect to

else
    echo "not deleted";

?>