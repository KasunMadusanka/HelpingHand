<html>

<head>
	
	<style type="text/css">
	table
		{
			border: 2px solid red;
			background-color: aqua;
			width: 80%;
		}
	
		th{
			border-bottom: 2px solid #000;
		}
	
		td
		{
			border-bottom: 2px solid #666;
		}
		
		
	</style>
	
	
	
	
	
    <meta charset="utf-8">
    <title>Individual Register</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-theme.css">
    <link rel="stylesheet" href="custom1.css">
    <link rel="stylesheet" href="icon.css">
    <link rel="stylesheet" href="awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	
	
	
</head>

<body>

    <div class="jamo">

        <div class="container">
            <h3>Helping Hand</h3>
            <h1>JOIN with us</h1>



            <div class="container" style="margin-top:50px">
                <div class="row">
                    <div class="col-md-offset-1 col-md-11 col-md-offset-1">
                        <div class="panel panel-default">
                            <div class="panel-body">

                                <form action="" class="col-md-12" style="margin-top:0px padding-top: 0px;">

                                    <div class="col-md-8">

                                   </div>

                                    <div class="col-md-4">
                                        <h2 style="color:yellow;margin-top:40px;text-align: center;font-size:50px;">WELCOME</h2>
                                        
                                    </div>


                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
		
		
		
	<br><br><h2> Select A Pauper To Donate </h2><br>	
		<br>
		
		
		
	<?php
		 
		include('connection.php');
		
		$conn = Connect();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	$sqlget = "SELECT u.* , b.* , h.* , m.* FROM ((( user u JOIN  pauper b on u.uid=b.uid) JOIN help h on b.pid=h.pid) JOIN money_request m on h.helpid=m.helpid ) where u.uid=b.pid";
	
	
	
   // $sqlget = "SELECT u.*, b.*  FROM user u JOIN pauper b ON u.uid = b.uid";
	//$sqlget = "SELECT * FROM user u JOIN pauper p ON u.uid = p.uid ";
	//$sqlget2 = "SELECT * from help "
	
	//JOIN help h on p.pid=h.pid JOIN money_request m on h.hid=m.hid ";
	
	
//	$sqlget= "select user.* , pauper.* ,help.* ,money_request.* from user,pauper,help,money_request where user.uid=pauper.uid AND pauper.pid=help.pid AND help.helpid=money_request.helpid";
	
	
	
		$sqldata = mysqli_query($conn,$sqlget) or die ('error getting');
		echo "<table>";
	echo "<t>";
		echo"<tr><th>uid</th><th>name</th><th>address</th><th>nic</th><th>phoneno</th><th>email</th><th>area</th><th>button</th></tr>";
		while($row = mysqli_fetch_array($sqldata,MYSQLI_ASSOC))
		{
			echo "<tr><td>";
			echo $row['uid'];
			echo "</td><td>";
			echo $row['name'];
			echo "</td><td>";
			echo $row['address'];
		
			echo "</td><td>";
			echo $row['nic'];
			echo "</td><td>";
			echo $row['phoneno'];
			echo "</td><td>";
			echo $row['email'];
			echo "</td><td>";
			echo $row['area'];
			echo "</td><td>";
			
			echo "<a href='donor_money.php'><button name='submit'>  Selet To Donate  </button></a>";
			echo "</td></tr>";
		}
		echo "</table>";
		?>
	
	
	
	
	
	<footer class="site-footer">
        <div class="container">
            <div class="row">


                <div class="col-md-2">
                    <p class="footer">Helping Hand </p>
                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="glyphicon glyphicon-envelope fa-2x"></i></a>
                    <a href="Helpinghand@gmail.com">Helpinghand@gmail.com</a><br><br>
                    <a href="sitemap.html">site map</a>

                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                    <a href="https://www.facebook.com/x">https://www.facebook.com</a>
                </div>





                <div class="github" style="padding-top:20px">
                    <a href="#"><i class="fa fa-github fa-2x"></i></a> - <a href="https://github.com/KasunMadusanka/testing">https://github.com/KasunMadusanka/testing</a>
                </div>


            </div>

            <div class="bottom-footer">
                <div class="col-md-6"> </div>

            </div>


        </div>

    </footer>
	
	
	
	
	
	
	
	
	</body></html>