<?php
 require 'connection.php';
$conn    = Connect();

$amount    = $conn->real_escape_string($_POST['amount']);










 $resultsets = mysqli_query($conn,"select donor.did FROM (user INNER JOIN donor on user.uid=donor.uid)");
 if($resultsets->num_rows > 0){
   while($rows = $resultsets->fetch_assoc()){  
        $ename = $rows['did'];
       
     echo $ename;
 //  echo "<br>";
	   
	 //  $userid = mysqli_insert_id($conn);

$query1   = mysqli_query($conn,"INSERT into money_donor(amount,did) VALUES('" . $amount . "','" .$ename . "')");
 
 }

 
 }  


if (!($query1)) {
  die("Couldn't enter data: ".$conn->error);
 
}
//header("Location: http://www.waitroseflorist.com/flowers/flowers/");

header("Location:donor_reg.php");

//echo "Thank You For Contacting Us <br>";
 
$conn->close();
 


	   
	   
  







$conn->close();

?>

