<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Individual Register</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-theme.css">
    <link rel="stylesheet" href="custom2.css">
    <link rel="stylesheet" href="icon.css">
    <link rel="stylesheet" href="awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

    <div class="jamo">

        <div class="container">
            <h3>Helping Hand</h3>
            <h1>JOIN with us</h1>



            <div class="container" style="margin-top:50px">
                <div class="row">
                    <div class="col-md-offset-1 col-md-11 col-md-offset-1">
                        <div class="panel panel-default">
                            <div class="panel-body">

					
                                
                                    <div class="col-md-8">
                            </div>
    <div class="col-md-4">
                                        <h2 style="color:yellow;margin-top:40px;text-align: center;font-size:50px;">WELCOME</h2>
                                        
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container" style="margin-top:0px; padding-top: 0px; padding-left:0px;">
        <div class="row">
          <form action="pauper_reg_server.php" method="post" style="margin-top:0px; padding-top: 0px; padding-left:0px;">  

                <div class="col-md-8">

                    <h2>Personal Details</h2>
                    
                     
					<div class="form-group-2">
                        <label for="name" class="col-md-3 lig">Name </label>
                        <div>
                            <input type="text" name="name" class="form-control-2" id="name" placeholder=" Enter Name" required>
                        </div>
                    </div>

                    <div class="form-group-2">
                        <label for="inputEmail" class="col-md-3 lig">Email </label>
                        <div>
                            <input type="text" name="email" class="form-control-2" id="email" placeholder=" Enter Email" required>
                        </div>
                    </div>

                     

                    <div class="form-group-2">
                        <label for="password" class="col-md-3 lig">Password</label>
                        <div>
                            <input type="password" name="password" class="form-control-2" id="password" placeholder="************" required>
                        </div>
                    </div>                    
                    
                  <div class="form-group-2">
                        <label for="address" class="col-md-3 lig">Address </label>
                        <div>
                            <input type="text" name="address" class="form-control-2" id="address" placeholder=" Enter Address" required>
                        </div>
                    </div>

					
					<div class="form-group-2">
                        <label class="col-md-3 lig">Area </label>
                        <div>
                            <input type="text" name="area" id="area" class="form-control-2" placeholder="Enter Area" required>
                        </div>
                    
				</div>
					
					


                    <div class="form-group-2">
                        <label class="col-md-3 lig">NIC no </label>
                        <div>
                            <input type="text" name="nic" id="nic" class="form-control-2" placeholder="XXXXXXXXXV" required>
                        </div>
                    </div>



                    <div class="form-group-2">
                        <label class="col-md-3 lig">Phone no </label>
                        <div>
                            <input type="text" name="phoneno" id="phoneno" class="form-control-2" placeholder="(+94)000000000" required>
                        </div>
                    
				</div>
					
					
					
					
					
					
					
					
					
             
					<div class="form-group">

                    </div>
                    
					<a href="donor2.php">  <button type="submit">Register</button></a>
					
				

       

	  



         
			  </div></form>

		</div></div>

 <!--Start of the footer-->

    <footer class="site-footer">
        <div class="container">
            <div class="row">


                <div class="col-md-2">
                    <p class="footer">Helping Hand </p>
                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="glyphicon glyphicon-envelope fa-2x"></i></a>
                    <a href="Helpinghand@gmail.com">Helpinghand@gmail.com</a><br><br>
                    <a href="sitemap.html">site map</a>

                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                    <a href="https://www.facebook.com/x">https://www.facebook.com</a>
                </div>





                <div class="github" style="padding-top:20px">
                    <a href="#"><i class="fa fa-github fa-2x"></i></a> - <a href="https://github.com/KasunMadusanka/testing">https://github.com/KasunMadusanka/testing</a>
                </div>


            </div>

            <div class="bottom-footer">
                <div class="col-md-6"> </div>

            </div>


        </div>

    </footer>

    <!--End Of the Footer-->

</body>





</html>