<?php 

$output = NULL;

if(isset($_POST['login'])){
    
 //   echo "welcome";

$mysqli = NEW MySQLi("localhost","root","","anu");

$search1 = $mysqli->real_escape_string($_POST['email']);
$search2 = $mysqli->real_escape_string($_POST['password']);   
    
    
    $email = $_POST['email'];
 $password = $_POST['password'];

//echo $email;
//echo $password;

$resultset = $mysqli->query("select * FROM user WHERE  email ='$email' and password = '".md5($password)."'");

    
    
    
if($resultset->num_rows > 0){
   while($rows = $resultset->fetch_assoc()){
        $ename = $rows['uid'];
       // $date = $rows['date'];
       // echo $date;
   }
    echo $ename;
    
    
    
    
    $resultsets = $mysqli->query("select * FROM pauper WHERE  uid ='$ename'");
    
    
    
    
    
     while($rows = $resultsets->fetch_assoc()){
        $enames = $rows['pid'];
       // $date = $rows['date'];
     }
    
    
    
    
    $resultsetsd = $mysqli->query("select * FROM donor WHERE  uid ='$ename'");
    
    
    
    
     while($rows = $resultsetsd->fetch_assoc()){
        $ena = $rows['did'];
       // $date = $rows['date'];
     }
    
    
    
    
    
    
     $resultsetsdveri = $mysqli->query("select * FROM verifier WHERE  uid ='$ename'");
    
    
    
    
     while($rows = $resultsetsdveri->fetch_assoc()){
        $vid = $rows['verifierid'];
         echo "veri";
       // $date = $rows['date'];
     }
    
    
    
    if((($enames)>=1)||(($ena)>=1)||(($vid)>=1)){
    
    if(($enames)>=1){
    //echo "pauper";
    header("Location:pauper_check.php");    
    }
    
    else if(($ena)>=1){
   // echo "donor";
    header("Location:donor_check.php");       
    }
        
    else if(($vid)>=1){
    //echo "veri";
    header("Location:verifier.php"); 
	//	header("Location:db4.php"); 
    }   
        
        
    }
    else{
    echo "error display";
    
    }
    
    
    
}else


{
$output = "No results";
}


}
?>