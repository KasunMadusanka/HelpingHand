<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Select Event</title>
   <link rel="stylesheet" href="bootstrap.min.css">
   <link rel="stylesheet" href="bootstrap-theme.css"> 
    <link rel="stylesheet" href="custom2.css ">
    <link rel="stylesheet" href="icon.css">  
  <link rel="stylesheet" href="awesome.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style type="text/css">
	table
		{   margin-left: 60px;
			border: 2px solid red;
			background-color:beige;
            width: 80%;
		}
	
		th{
			border-bottom: 5px solid #000;
		}
	
		td
		{
			border-bottom: 2px solid #666;
           
		}
		
		
	</style>
</head>

<body>

    <div class="jamo">

        <div class="container">
            <h3>Helping Hand</h3>
            <h1>JOIN with us</h1>



            <div class="container" style="margin-top:50px">
                <div class="row">
                    <div class="col-md-offset-1 col-md-11 col-md-offset-1">
                        <div class="panel panel-default">
                            <div class="panel-body">

                               <!-- <form action="" class="col-md-12" style="margin-top:0px padding-top: 0px;">-->

                                   <!-- <div class="col-md-8">

                                     </div> -->

                                    <div class="col-md-4">
                                        <h2 style="color:yellow;margin-top:40px;text-align: center;font-size:50px;">WELCOME</h2>
                                        
                                    </div>


                               <!-- </form>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    


        

                

                    <h2>Select Event</h2>

                
                    
                    
                    
                    <?php   
                    
                     
    
              
    
                      if(isset($_POST['submit'])){

                       $mysqli = NEW MySQLi("localhost","root","","anu");

                          
                          $delete = mysqli_query($mysqli, "DELETE from event_request where event_date <= CAST(CURRENT_TIMESTAMP AS DATE)");
                          mysqli_query($mysqli, $delete);
                         
                          
                          
                          
                       $search = $mysqli->real_escape_string($_POST['search']);
                                           
                       $resultset = $mysqli->query("select * FROM event_request  WHERE area LIKE '$search'");


                       echo "<table>";
	                   echo "<t>";
		               echo"<tr><th>Event</th> <th>Dicription</th> <th>date</th> <th>Time_From</th>  <th>Time_to</th>  <th>Venue</th>  </tr>";



                       while($row = mysqli_fetch_array($resultset,MYSQLI_ASSOC))
		               {
			echo "<tr><td>";
			echo $row['event_name'];
			echo "</td><td>";
            echo $row['discription'];
			echo "</td><td>";
			echo $row['event_date'];
            echo "</td><td>";
			echo $row['time_from'];
			echo "</td><td>";
			echo $row['time_to'];
			echo "</td><td>";
			echo $row['venue'];
			echo "</td></tr>";
		}
		echo "</table>";
                      }
                 
	
	
                    ?>
    
    
        <div class="form-group"></div>

	<div class="form-group"> <button type="submit" style="padding-left=50px;"class="btn-noveri" name="submit" value="search"><a href="finalhtml.html">EXIT</a></button></div>
                    
                    
                            
                
  






    <!--Start of the footer-->

    <footer class="site-footer">
        <div class="container">
            <div class="row">


                <div class="col-md-2">
                    <p class="footer">Helping Hand </p>
                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="glyphicon glyphicon-envelope fa-2x"></i></a>
                    <a href="Helpinghand@gmail.com">Helpinghand@gmail.com</a><br><br>
                    <a href="sitemap.html">site map</a>

                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                    <a href="https://www.facebook.com/x">https://www.facebook.com</a>
                </div>





                <div class="github" style="padding-top:20px">
                    <a href="#"><i class="fa fa-github fa-2x"></i></a> - <a href="https://github.com/KasunMadusanka/testing">https://github.com/KasunMadusanka/testing</a>
                </div>


            </div>

            <div class="bottom-footer">
                <div class="col-md-6"> </div>

            </div>


        </div>

    </footer>

    <!--End Of the Footer-->

</body>
</html>