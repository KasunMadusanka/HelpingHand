<html>
<br><br><br><br><br><br><br>
<center>
<div id="content">
        <form method="post" action="slip_upload.php" enctype="multipart/form-data">
          <input type="hidden" name="size" value="1000000">
            
             <div class="form-group-2">
                 <div>       
                 <label class="col-md-3 lig">Slip: </label>
                        
                           <input type="file" name="image" required>
                            
                        </div>
                    </div>
            <br><br>
            <div>
            Input select money requested id:<input type="text" name="userid" required>
                 </div>
            
            <br><br>
            
            
            <br><br>
            
            <div>
                <textarea name="text" cols="40" rows="4" placeholder="say something about this image..."></textarea>
            </div>
            
            
            <div>
                <button name="upload">Upload slip<a href='login2.php'></a></button>
            </div>
			<br><br><br>
         <!--   <button><a href="finalhtml.html">Gallary</a></button>  -->
        </form>
        
        </div>
</center>
<html>