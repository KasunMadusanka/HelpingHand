<?php
//echo "welcome";
$msg = "";

 //if upload button is pressed name of button
if(isset($_POST['veri'])){
  // echo "hi";
     //connect to the database
    $db = mysqli_connect("localhost","root","","anu");
    
   // echo "welcome";
    
 $resultsets = mysqli_query($db,"select pauper.pid FROM (user INNER JOIN pauper on user.uid=pauper.uid)");
    
if($resultsets->num_rows > 0){
   while($rows = $resultsets->fetch_assoc()){  
        $pid = $rows['pid'];
     //   echo $pid;
   }
 }
    
  

    
   
     //the path to store the upload image
 //  $target = "images/".basename($_FILES['image']['name']);
    
   $target = "images/".basename($_FILES['image']['name']);
    //get all the subnetted data from the form
    
    $ra = $_POST['ra'];
    $accountno = $_POST['accountno'];
    $due_date =  $_POST['due_date'];
    $area = $_POST['area'];
	$fname = $_POST['fname'];
	$discription = $_POST['discription'];
   // $doc = $_FILES['image']['name'];
    
	 $doc = $_FILES['image']['name'];
   
    
  // echo $area;
    
    
    //get verifier id
    $getVid = mysqli_query($db,"select * FROM verifier WHERE area='$area'");
    
    
    if($getVid->num_rows > 0){
    
     while($rows = $getVid->fetch_assoc()){
        $vid = $rows['verifierid'];
      //   echo $vid;
     }
    
    }
    
    
    
    
    
    //insert data into help table
    $sql = "INSERT INTO help(is_verified,verifierid,pid,document,area) VALUES ('0','$vid','$pid','$doc','$area')";
    mysqli_query($db,$sql);
    
    
    
     $getHelpId = mysqli_query($db,"select * FROM help WHERE pid='$pid'");
    
    
    if($getHelpId->num_rows > 0){
     while($rows = $getHelpId->fetch_assoc()){
        $hid = $rows['helpid'];
     }
    }

    

    $sql1 = "INSERT INTO money_request(required_amount,accountno,due_date,helpid,area,fname,discription) VALUES ( '$ra','$accountno','$due_date','$hid','$area','$fname','$discription')";
    mysqli_query($db,$sql1);
    
       header("location: pending.php");  
}
?>