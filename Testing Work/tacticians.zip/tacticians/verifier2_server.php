<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Select Event</title>
   <link rel="stylesheet" href="bootstrap.min.css">
   <link rel="stylesheet" href="bootstrap-theme.css"> 
    <link rel="stylesheet" href="custom2.css ">
    <link rel="stylesheet" href="icon.css">  
  <link rel="stylesheet" href="awesome.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style type="text/css">
	table
		{   margin-left: 60px;
			border: 2px solid red;
			background-color:beige;
            width: 80%;
		}
	
		th{
			border-bottom: 5px solid #000;
		}
	
		td
		{
			border-bottom: 2px solid #666;
           
		}
		
		
	</style>
</head>

<body>

    <div class="jamo">

        <div class="container">
            <h3>Helping Hand</h3>
            <h1>JOIN with us</h1>



            <div class="container" style="margin-top:50px">
                <div class="row">
                    <div class="col-md-offset-1 col-md-11 col-md-offset-1">
                        <div class="panel panel-default">
                            <div class="panel-body">

                               <!-- <form action="" class="col-md-12" style="margin-top:0px padding-top: 0px;">-->

                                   <!-- <div class="col-md-8">

                                     </div> -->

                                    <div class="col-md-4">
                                        <h2 style="color:yellow;margin-top:40px;text-align: center;font-size:50px;">WELCOME</h2>
                                        
                                    </div>


                               <!-- </form>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    


        

                

                    <h2>Verify The Paupers</h2>

                
                    
                    
                    
                    <?php   
                    
                 
                      
    
    
    
    
    
                      if(isset($_POST['submit'])){
                          
                          
                           $db = NEW MySQLi("localhost","root","","anu");
                          
                          
                          // $sqlget = $mysqli->query("SELECT u.*, b.*  FROM user u JOIN pauper b ON u.uid = b.uid");
	$sqlget = "SELECT u.* , b.* , h.* , v.* FROM ((( user u JOIN  pauper b on u.uid=b.uid) JOIN help h on b.pid=h.pid) JOIN verifier v on h.verifierid=v.verifierid ) WHERE b.area=v.area";
	

		$sqldata = mysqli_query($db,$sqlget) or die ('error getting');
		echo "<table>";
	echo "<t>";
	//	echo"<tr><th>name</th><th>address</th><th>nic</th><th>phoneno</th><th>email</th><th>area</th><th>document</th><th>button</th></tr>";
						  
		
						  echo"<tr><th>helpid</th><th>name</th><th>address</th><th>nic</th><th>phoneno</th><th>email</th><th>area</th><th>document</th><th>button</th></tr>";
						  
						  
						  
						  
		while($row = mysqli_fetch_array($sqldata,MYSQLI_ASSOC))
		{
			
		//	echo "</td><td>";
			
			
			echo "<tr><td>";
			
			
			echo $row['helpid'];
			echo "</td><td>";
			
			
			echo $row['name'];
			echo "</td><td>";
			echo $row['address'];
		
			echo "</td><td>";
			echo $row['nic'];
			echo "</td><td>";
			echo $row['phoneno'];
			echo "</td><td>";
			echo $row['email'];
			echo "</td><td>";
			echo $row['area'];
			echo "</td><td>";
			
			echo $row['document'];
			echo "</td><td>";
			
			
            echo "<a href=update.php?helpid=".$row['helpid']."><button name='submit'> verify  </button></a>";
            
			
			//echo "<a href='donor_money.php'><button name='submit'>  verified  </button></a>";
			echo "</td></tr>";
		}
		echo "</table>";}
	
	
		?>
			
			
    
    

    






    <!--Start of the footer-->

    <footer class="site-footer">
        <div class="container">
            <div class="row">


                <div class="col-md-2">
                    <p class="footer">Helping Hand </p>
                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="glyphicon glyphicon-envelope fa-2x"></i></a>
                    <a href="Helpinghand@gmail.com">Helpinghand@gmail.com</a><br><br>
                    <a href="sitemap.html">site map</a>

                </div>


                <div class="col-md-3" style="padding-top:20px">
                    <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                    <a href="https://www.facebook.com/x">https://www.facebook.com</a>
                </div>





                <div class="github" style="padding-top:20px">
                    <a href="#"><i class="fa fa-github fa-2x"></i></a> - <a href="https://github.com/KasunMadusanka/testing">https://github.com/KasunMadusanka/testing</a>
                </div>


            </div>

            <div class="bottom-footer">
                <div class="col-md-6"> </div>

            </div>


        </div>

    </footer>

    <!--End Of the Footer-->

</body>
</html>